Папку Workspace нужно поместить в корень свежеустановленной (т.е. без изменённых файлов) игры The Park

Описание скриптов в пакете (т.е. что они позволяют делать):

unpack_pak_file.bat — распаковать в папку с игрой и переименовать AtlanticIslandPark-WindowsNoEditor.pak
create_locres.bat — создать из Game.locres.txt (в этот файл нужно вписывать перевод) .locres-файл для игры и разместить его в правильном месте
extract_textures.bat — распаковать и сконвертировать в PNG текстуры (список в ConvertedTextures\_textures.txt, текстуры будут размещены в папке ConvertedTextures), полученные .png-файлы можно редактировать (команду крайне не рекомендуется запускать повторно)
restore_textures.bat — собрать .uasset-файлы с отредактированными файлами (результат будет в папке ConvertedTextures\Result, перед выполнением сборки папка Result удаляется) (после запуска этой команды крайне не рекомендуется запускать extract_textures.bat)
copy_restored_textures_to_game.bat — скопировать результат работы предыдущей команды в папку игры (после запуска этой команды крайне не рекомендуется запускать extract_textures.bat)
extract_fonts.bat — распаковать шрифты из игры в папку Fonts в формате ttf (после этого можно править ttf-файлы или заменять на другие, сохраняя имена)
replace_fonts.bat — заменить игровые шрифты на те, что лежат в папке Fonts
make_result.bat — собрать всё из ConvertedTextures\Result + .locres-файл + файлы со шрифтами в папку result (это что-то типа файлов для pak-файла итогового русификатора)
make_pak.bat — собрать из файлов в папке result итоговый pak-файл AtlanticIslandPark-Russian.pak (если его положить в <папка игры>\AtlanticIslandPark\Content\Paks (на чистую копию игры без каких либо распаковок), то включится русификация)