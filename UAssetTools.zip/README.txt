Old version!
Archive move to: https://github.com/VD42/UE4Tools/raw/master/UE4Tools.zip